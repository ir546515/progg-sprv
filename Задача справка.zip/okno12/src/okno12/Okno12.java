/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package okno12;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
 
public class Okno12 implements ActionListener {
 
   public Okno12() {
      initComponents();
   }
 
   private JFrame viewForm;
 
   private void initComponents() {
      viewForm = new JFrame("Окно");
      viewForm.setSize(320, 160);
      viewForm.setVisible(true);
      viewForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      
 
      JButton button1 = new JButton("Начать работу");
      button1.setVisible(true);
      button1.setLocation(150, 50);
      button1.setSize(150, 20);

      
      JButton button = new JButton("Подробнее");
      button.setVisible(true);
      button.setLocation(40, 50); //(влево, вниз); 
      button.setSize(100,20); //(ширь, Высота)
      button.addActionListener(new ActionListener() {
 
          public void actionPerformed(ActionEvent arg0) {
                          
new Izfile2("Текст", 300, 400);


         }
 
      });
      viewForm.getContentPane().add(button1);
      viewForm.getContentPane().add(button);
      viewForm.getContentPane().add(new JLabel());
   }
 
   public void actionPerformed(ActionEvent action) {
   }
 
   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            new Okno12();
         }
      });
   }
}
///**
// *
// * @author User
// */
//public class Okno12 {
//
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//    }
//    
//}
